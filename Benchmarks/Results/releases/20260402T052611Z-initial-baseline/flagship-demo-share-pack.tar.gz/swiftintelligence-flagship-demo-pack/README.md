# SwiftIntelligence Flagship Demo Share Pack

Use this pack when preparing a release post, evaluator handoff, or short showcase asset wave for the strongest current demo path.

## Included Files

- `Documentation/Generated/Flagship-Demo-Pack.md`
- `Documentation/Generated/Flagship-Media-Status.md`
- `Documentation/Generated/Public-Proof-Status.md`
- `Documentation/Generated/Latest-Release-Proof.md`
- `Documentation/Showcase.md`
- `Examples/DemoApps/IntelligentCamera/README.md`
- `Examples/DemoApps/IntelligentCamera/IntelligentCameraApp.swift`
- `Documentation/Assets/Flagship-Demo/*` when repo-native media is published

## Fastest Use

1. Read `Documentation/Generated/Flagship-Demo-Pack.md`.
2. Open `Examples/DemoApps/IntelligentCamera/README.md`.
3. Run the demo path on `macOS 14+` or `iOS 17+`.
4. If repo-native media assets are included, reuse them only with the same proof posture and caption.
5. Otherwise capture one screenshot and one short recording only after the visible success signals are present.

## Recommended Asset Names

- `intelligent-camera-success.png`
- `intelligent-camera-run.mp4`
- `caption.txt`

## Caption Baseline

`Vision -> NLP -> Privacy in one Apple-native Swift package workflow`

## Truthfulness Rules

- do not present simulator output as mobile release evidence
- do not crop out missing or empty success signals
- do not claim category leadership from demo media alone
